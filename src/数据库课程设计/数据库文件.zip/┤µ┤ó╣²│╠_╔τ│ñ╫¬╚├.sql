create procedure AssociationLeaderChange (@AID varchar(20),@SID varchar(20))
as
	begin
	update Association
	set Association.Student_ID=@SID
	from JoinIn,Association
	where JoinIn.Association_ID=@AID and JoinIn.Student_ID=@SID and JoinIn.Association_ID=Association.Association_ID
	end