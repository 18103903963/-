create procedure NewActivity(@SID varchar(20),@ACID varchar(20),@dt date,@nm varchar(20),@tp varchar(20))
as
	begin
	insert into Activity values(@nm,@ACID,@tp,@dt,@SID)
	end