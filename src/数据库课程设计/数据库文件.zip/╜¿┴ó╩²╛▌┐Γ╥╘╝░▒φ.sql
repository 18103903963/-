create database Student_association
create table Student
(
	Student_Name varchar(10) not null,
	Student_ID varchar(20) primary key,
	Student_Telephone varchar(20) not null,
	Student_Sex varchar(5) not null,
	Student_Grade varchar(20) not null,
	Student_Academy varchar(20) not null
)
create table Association
(
	Association_Name varchar(20) not null,
	Association_ID varchar(20) primary key,
	Association_Type varchar(20) not null,
	Student_ID varchar(20) foreign key (Student_ID) references Student 
)
create table Activity
(
	Activity_Title varchar(20) not null,
	Activity_ID varchar(20) primary key,
	Activity_Type varchar(20) not null,
	Activity_Date date not null,
	Association_ID varchar(20) foreign key(Association_ID) references Association
)
create table TakePartIn
(
	Student_ID varchar(20) foreign key(Student_ID) references Student,
	Activity_ID varchar(20) foreign key(Activity_ID) references Activity
)
create table JoinIn
(
	Association_ID varchar(20) foreign key(Association_ID) references Association,
	Student_ID varchar(20) foreign key(Student_ID) references Student,
	JionInDate date not null,
	Post varchar(20)
)