alter procedure AssociationInquire
as
	begin
	select Association_Name+'   '+Association_ID as result
	from Association
	end