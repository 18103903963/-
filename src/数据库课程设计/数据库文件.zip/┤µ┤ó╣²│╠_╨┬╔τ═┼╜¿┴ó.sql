alter procedure NewAssociation(@nm varchar(20),@xh varchar(20),@tp varchar(20),@ID varchar(20))
as
	begin
	INSERT INTO Association VALUES(@nm,@ID,@tp,@xh)
	INSERT INTO JoinIn values(@ID,@xh,GETDATE(),'�糤')
	end