alter procedure MemberDelete (@SID varchar(20),@AID varchar(20))
as
	begin
	delete 
	from JoinIn
	where @SID=Student_ID and @AID=Association_ID
	end