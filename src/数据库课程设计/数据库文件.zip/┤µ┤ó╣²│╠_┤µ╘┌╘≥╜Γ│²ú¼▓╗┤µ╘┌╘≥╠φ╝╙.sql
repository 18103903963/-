alter procedure Judge(@SID varchar(20),@AID varchar(20))
as
	begin

	if @SID=(select Student_ID from JoinIn where Association_ID=@AID and Student_ID=@SID)
		exec MemberDelete @SID,@AID
	else
		exec NewMemberJoin @AID,@SID,''
	end