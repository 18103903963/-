alter procedure AssociationMemberInquire (@nm varchar(20))
as
	begin
	select Student_Name+'   '+Student.Student_ID+'   '+Student_Sex+'   '+Student.Student_Telephone+'   '+Student.Student_Grade as result
	from Student,Association,JoinIn
	where Association.Association_ID=@nm and @nm=JoinIn.Association_ID and Student.Student_ID = JoinIn.Student_ID
	end