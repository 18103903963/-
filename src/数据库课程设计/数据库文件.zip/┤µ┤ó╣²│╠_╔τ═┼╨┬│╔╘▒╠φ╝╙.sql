alter PROCEDURE NewMemberJoin (@AID varchar(20),@SID varchar(20),@Work varchar(20))
as
	begin
	INSERT INTO JoinIn VALUES(@AID,@SID,getdate(),@Work)
	end