create procedure EditAssociation(@nm varchar(20),@xh varchar(20),@tp varchar(20),@ID varchar(20))
as
	begin
	update Association
	set Association_Name = @nm,Association_Type=@tp,Student_ID=@xh
	where @ID=Association_ID
	end