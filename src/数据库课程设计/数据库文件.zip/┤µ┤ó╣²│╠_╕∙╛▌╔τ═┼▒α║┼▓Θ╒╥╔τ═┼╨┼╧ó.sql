ALTER procedure AssociationSearchByID (@s varchar(20))
as
begin
	select Association_ID+'   '+Association_Name+'   '+Association_Type+'   '+Student_ID as result
	from Association
	where Association_ID=@s
end